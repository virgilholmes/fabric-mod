This is a resource pack that simply removes a single texture from Minecraft aka the pumpkin blur texture. 

As long as Mojang doesn't move where they keep the texture file or the name of the texture file, technically every version of the pack should be compatible with every version of Minecraft (even if the resource pack version number isn't correct for the running version of Minecraft)

This pack can be found on both [Curse Forge](https://www.curseforge.com/minecraft/texture-packs/no-more-pumpkin-blur-pack) and [Modrinth](https://modrinth.com/resourcepack/no-more-pumpkin-blur).
